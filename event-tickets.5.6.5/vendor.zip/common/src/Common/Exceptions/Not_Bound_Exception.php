<?php

namespace TEC\Common\Exceptions;

use RuntimeException;

/**
 * Class Not_Bound_Exception.
 *
 * @since 5.1.1.2
 *
 * @package TEC\Common\Exceptions
 */
class Not_Bound_Exception extends Container_Exception {
	// Intentionally empty.
}